<?php declare(strict_types=1);

namespace App\Controller\Base\Constants;

class ResponseFormat
{
    public const JSON = 'json';
    public const JSONLD = 'jsonld';
}
