<?php

declare(strict_types=1);

namespace App\Component\Core\Exceptions;

use Exception;

class ModelNotFoundException extends Exception
{
}
